==CLIENT==
Per eseguire il client è necessario eseguire lo script:
./clientexec 

Dopodichè una volta avviato il container, eseguire lo script bash per avviare il client:
./start [IP_SERVER]
#NB. Il server deve essere in esecuzione per far sì che la connessione avvenga

________________________________________

==SERVER==
Per eseguire il server è necessario eseguire lo script:
./serverexec

Dopodichè una volta avviato il container, eseguire lo script bash per avviare il server:
./start

_______________________________________
