==SERVER==
Per eseguire il client è necessario eseguire lo script:
./clientexec

Dopodichè una volta avviato il container, eseguire lo script bash per avviare il client:
./start
#NB. Il server deve essere in esecuzione per far sì che la connessione avvenga
_______________________________________

==CLIENT==
Per eseguire il client è necessario eseguire lo script:
./clientexec

Dopodichè una volta avviato il container, eseguire lo script bash per avviare il client:
./start
#NB. Il server deve essere in esecuzione per far sì che la connessione avvenga

________________________________________
